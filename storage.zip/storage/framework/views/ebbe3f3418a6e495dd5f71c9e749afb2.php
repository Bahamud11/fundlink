<div>
    <div class="flex items-start justify-between mb-8">
        <div>
            <h2 class="text-3xl font-bold text-gray-800">Selamat Datang, <?php echo e(auth()->user()->name); ?> 👋</h2>
            <p class="text-gray-400 text-sm mt-1">Berikut ringkasan keuangan yayasan.</p>
        </div>
        
        <!-- Notification Bell -->
        <a href="<?php echo e(route('notifications')); ?>" class="relative p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200 mt-2">
            <span class="absolute top-2 right-2 h-2.5 w-2.5 bg-red-500 rounded-full border-2 border-white"></span>
            <svg class="h-7 w-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
            </svg>
        </a>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Saldo Card -->
        <div class="bg-blue-600 p-6 rounded-2xl shadow-lg shadow-blue-200 text-white">
            <div class="flex items-center space-x-2 mb-8">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
                    <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
                    <path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z" />
                </svg>
                <span class="text-sm font-medium">Saldo</span>
            </div>
            <p class="text-3xl font-bold">Rp <?php echo e(number_format($saldo, 0, ',', '.')); ?>,00</p>
        </div>

        <!-- Pemasukan Card -->
        <div class="bg-gradient-to-br from-blue-50 to-white p-6 rounded-2xl border border-blue-100 shadow-sm">
            <div class="flex items-center space-x-2 mb-8 text-blue-600">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M23 6l-9.5 9.5-5-5L1 18" />
                    <path d="M17 6h6v6" />
                </svg>
                <span class="text-sm font-medium text-gray-500">Pemasukan</span>
            </div>
            <p class="text-3xl font-bold text-gray-800">Rp <?php echo e(number_format($totalPemasukan, 0, ',', '.')); ?>,00</p>
        </div>

        <!-- Pengeluaran Card -->
        <div class="bg-gradient-to-br from-red-50 to-white p-6 rounded-2xl border border-red-100 shadow-sm">
            <div class="flex items-center space-x-2 mb-8 text-red-500">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M23 18l-9.5-9.5-5 5L1 6" />
                    <path d="M17 18h6v-6" />
                </svg>
                <span class="text-sm font-medium text-gray-500">Pengeluaran</span>
            </div>
            <p class="text-3xl font-bold text-gray-800">Rp <?php echo e(number_format($totalPengeluaran, 0, ',', '.')); ?>,00</p>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm mb-8">
        <div class="flex flex-col lg:flex-row lg:items-start lg:justify-between">
            <!-- Left Side: Bar Chart -->
            <div class="flex-1">
                <div class="flex items-center space-x-2 mb-8 text-gray-500">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path d="M7 10l5 5 5-5M7 14l5-5 5 5" />
                    </svg>
                    <h3 class="text-lg font-semibold text-gray-600">Trend Mingguan</h3>
                </div>
                
                <div wire:ignore class="h-64 relative">
                    <canvas id="trendChart"></canvas>
                </div>

                <div class="flex justify-center space-x-8 mt-8">
                    <div class="flex items-center space-x-2">
                        <div class="w-3 h-3 rounded-full bg-blue-600"></div>
                        <span class="text-sm font-medium text-gray-500">Pemasukan</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <div class="w-3 h-3 rounded-full bg-blue-200"></div>
                        <span class="text-sm font-medium text-gray-500">Pengeluaran</span>
                    </div>
                </div>
            </div>

            <!-- Right Side: Filters & Donut -->
            <div class="lg:w-80 lg:ml-12 mt-12 lg:mt-0 flex flex-col space-y-8">
                <!-- Filters -->
                <div class="grid grid-cols-1 gap-6">
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-gray-400">Rentang</label>
                        <select wire:model.live="filterKategori" class="w-full bg-transparent border-none text-gray-400 font-medium p-0 focus:ring-0">
                            <option>Mingguan</option>
                            <option>Bulanan</option>
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label class="text-xs font-bold text-gray-400">Frekuensi</label>
                            <select wire:model.live="filterWaktu" class="w-full bg-transparent border-none text-gray-400 font-medium p-0 focus:ring-0">
                                <option>Minggu ke-1</option>
                                <option>Minggu ke-2</option>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="text-xs font-bold text-gray-400">Cabang</label>
                            <select wire:model.live="filterCabang" class="w-full bg-transparent border-none text-gray-400 font-medium p-0 focus:ring-0">
                                <option value="Semua">Pilih Cabang</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Donut Chart & Legend -->
                <div class="flex items-center justify-between pt-4">
                    <div class="space-y-4">
                        <div class="flex items-center space-x-3">
                            <div class="w-2 h-2 rounded-full bg-blue-600"></div>
                            <span class="text-xs font-bold text-gray-500">Pemasukan</span>
                            <span class="bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center">
                                <?php echo e($incomePercentage); ?>%
                                <svg class="h-2 w-2 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3">
                                    <path d="M5 15l7-7 7 7" />
                                </svg>
                            </span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="w-2 h-2 rounded-full bg-blue-200"></div>
                            <span class="text-xs font-bold text-gray-500">Pengeluaran</span>
                            <span class="bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center">
                                <?php echo e($expensePercentage); ?>%
                                <svg class="h-2 w-2 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3">
                                    <path d="M19 9l-7 7-7-7" />
                                </svg>
                            </span>
                        </div>
                    </div>
                    
                    <div wire:ignore class="h-32 w-32 relative">
                        <canvas id="categoryChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Transactions -->
    <div class="mb-8">
        <h3 class="text-lg font-bold text-gray-800 mb-6">Transaksi Terbaru</h3>
        <div class="space-y-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center justify-between group">
                <div class="flex items-center space-x-4">
                    <div class="p-2 rounded-lg <?php echo e($transaction->type === 'pemasukan' ? 'bg-blue-50 text-blue-600' : 'bg-red-50 text-red-500'); ?>">
                        <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($transaction->type === 'pemasukan' ? 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6' : 'M13 17h8m0 0V9m0 8l-8-8-4 4-6-6'); ?>" />
                        </svg>
                    </div>
                    <div>
                        <p class="font-bold text-gray-700"><?php echo e($transaction->category); ?></p>
                        <p class="text-xs text-gray-400"><?php echo e($transaction->unit->name); ?> <?php echo e($transaction->transaction_date->format('d, M Y')); ?></p>
                    </div>
                </div>
                <div class="text-right">
                    <p class="font-bold text-gray-600 text-lg">Rp <?php echo e(number_format($transaction->amount, 0, ',', '.')); ?>,00</p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        const initDashboardCharts = () => {
            let trendChart, categoryChart;

            const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

            const initCharts = (weeklyData, categoryData) => {
                const trendCanvas = document.getElementById('trendChart');
                const categoryCanvas = document.getElementById('categoryChart');

                if (!trendCanvas || !categoryCanvas) return;

                // Trend Chart
                const trendCtx = trendCanvas.getContext('2d');
                if (window.trendChartInstance) window.trendChartInstance.destroy();
                window.trendChartInstance = new Chart(trendCtx, {
                    type: 'bar',
                    data: {
                        labels: weeklyData.map(d => {
                            const date = new Date(d.date);
                            return dayNames[date.getDay()];
                        }),
                        datasets: [
                            {
                                label: 'Pemasukan',
                                data: weeklyData.map(d => d.income),
                                backgroundColor: '#2563eb', // blue-600
                                borderRadius: 4,
                                barThickness: 15,
                                categoryPercentage: 0.6,
                                barPercentage: 0.8
                            },
                            {
                                label: 'Pengeluaran',
                                data: weeklyData.map(d => d.expense),
                                backgroundColor: '#bfdbfe', // blue-200
                                borderRadius: 4,
                                barThickness: 15,
                                categoryPercentage: 0.6,
                                barPercentage: 0.8
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, grid: { display: false }, border: { display: false }, ticks: { display: false } },
                            x: { grid: { display: false }, border: { display: false }, ticks: { font: { weight: 'bold', size: 12 }, color: '#9ca3af' } }
                        }
                    }
                });

                // Category Chart (Donut)
                const categoryCtx = categoryCanvas.getContext('2d');
                if (window.categoryChartInstance) window.categoryChartInstance.destroy();
                window.categoryChartInstance = new Chart(categoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: categoryData.map(d => d.category),
                        datasets: [{
                            data: categoryData.map(d => d.total),
                            backgroundColor: ['#2563eb', '#60a5fa', '#93c5fd', '#bfdbfe', '#dbeafe'],
                            borderWidth: 0,
                            cutout: '80%'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } }
                    }
                });
            };

            // Initial load data
            const initialWeeklyData = <?php echo json_encode($weeklyData, 15, 512) ?>;
            const initialCategoryData = <?php echo json_encode($categoryData, 15, 512) ?>;
            initCharts(initialWeeklyData, initialCategoryData);

            // Listen for Livewire updates
            Livewire.on('chartUpdated', (eventData) => {
                const data = eventData[0];
                initCharts(data.weeklyData, data.categoryData);
            });
        };

        // Run on initial load and every navigation
        document.addEventListener('livewire:navigated', initDashboardCharts);
        document.addEventListener('livewire:initialized', initDashboardCharts);
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH C:\Users\Bahamud\Music\fundlink_rev\resources\views\livewire\dashboard.blade.php ENDPATH**/ ?>