<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active', 'icon']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active', 'icon']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$classes = ($active ?? false)
            ? 'flex items-center space-x-4 p-4 rounded-lg bg-blue-600 text-white transition-all duration-300 font-bold group'
            : 'flex items-center space-x-4 p-4 rounded-lg text-gray-400 hover:text-gray-600 transition-all duration-200 font-bold group';

$iconClasses = ($active ?? false)
            ? 'text-white'
            : 'text-gray-400 group-hover:text-gray-600 transition-colors duration-200';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?> wire:navigate>
    <div class="<?php echo e($iconClasses); ?>">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($icon === 'home'): ?>
            <!-- Layout Grid Icon -->
            <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <rect x="3" y="3" width="7" height="7" rx="1" />
                <rect x="14" y="3" width="7" height="7" rx="1" />
                <rect x="14" y="14" width="7" height="7" rx="1" />
                <rect x="3" y="14" width="7" height="7" rx="1" />
            </svg>
        <?php elseif($icon === 'receipt'): ?>
            <!-- Rp Circle Icon -->
            <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <circle cx="12" cy="12" r="9" />
                <path d="M10 8h3a2 2 0 1 1 0 4h-3v4" />
                <path d="M12 12l2 4" />
            </svg>
        <?php elseif($icon === 'office'): ?>
            <!-- Branches Icon -->
            <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <path d="M12 3v3" />
                <path d="M12 18v3" />
                <path d="M3 12h3" />
                <path d="M18 12h3" />
                <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                <path d="M18 6l-1.5 1.5" />
                <path d="M7.5 16.5L6 18" />
                <path d="M6 6l1.5 1.5" />
                <path d="M16.5 16.5L18 18" />
            </svg>
        <?php elseif($icon === 'users'): ?>
            <!-- User Outline Icon -->
            <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="10" cy="7" r="4" />
            </svg>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <span class="text-lg"><?php echo e($slot); ?></span>
</a>
<?php /**PATH C:\Users\Bahamud\Music\fundlink_rev\resources\views/components/sidebar-link.blade.php ENDPATH**/ ?>